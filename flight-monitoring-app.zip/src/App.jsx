import React, { useState, useEffect, useCallback } from 'react';
import Header from './components/Header';
import FlightTable from './components/FlightTable';
import { fetchFlightData } from './api/flightData';

function App() {
  const [arrivals, setArrivals]       = useState([]);
  const [departures, setDepartures]   = useState([]);
  const [loading, setLoading]         = useState(true);
  const [error, setError]             = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);

  const loadFlights = useCallback(async () => {
    try {
      setError(null);
      const data = await fetchFlightData();
      setArrivals(data.arrivals);
      setDepartures(data.departures);
      setLastUpdated(new Date());
    } catch (err) {
      console.error('Failed to fetch flight data:', err);
      setError('Unable to load flight data.');
    } finally {
      setLoading(false);
    }
  }, []);

  // Initial data load
  useEffect(() => {
    loadFlights();

    // ── SSE listener — server pushes reload after every API fetch ────────────
    const es = new EventSource('/api/events');
    es.addEventListener('reload', () => {
      console.log('🔄 SSE reload received — refreshing flights…');
      loadFlights();
    });
    es.onerror = () => console.warn('⚠️ SSE connection lost — auto-reconnecting…');

    // ── Polling fallback — force re-fetch every 1 minute ─────────────────────
    // Ensures the table stays fresh even if the SSE connection drops
    const pollInterval = setInterval(() => {
      console.log('🔁 1-min poll — refreshing flights…');
      loadFlights();
    }, 60_000);

    return () => {
      es.close();
      clearInterval(pollInterval);
    };
  }, [loadFlights]);

  const toggleFullScreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
    } else {
      document.exitFullscreen?.();
    }
  };

  return (
    <div className="app">
      <Header lastUpdated={lastUpdated} onRefresh={loadFlights} />

      {loading && (
        <div className="loading-overlay">
          <div className="spinner" />
          <p>Loading flight data…</p>
        </div>
      )}

      {error && !loading && (
        <div className="error-banner">{error}</div>
      )}

      {!loading && !error && (
        <main className="tables-grid">
          <FlightTable title="Arrivals" flights={arrivals} type="arrivals" />
          <FlightTable title="Departures" flights={departures} type="departures" />
        </main>
      )}

      <button onClick={toggleFullScreen} className="fullscreen-btn" title="Toggle Fullscreen">
        ⛶
      </button>
    </div>
  );
}

export default App;


